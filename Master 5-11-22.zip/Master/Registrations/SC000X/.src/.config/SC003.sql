(
        exists(

        select *

        from SFRSTCR r

        where r.SFRSTCR_PIDM = SPRIDEN.SPRIDEN_PIDM
            and r.SFRSTCR_TERM_CODE = STVTERM.STVTERM_CODE
            and r.SFRSTCR_RSTS_CODE like 'R%'
            and r.SFRSTCR_GMOD_CODE = 'Y'
            )

            and SGBSTDN.SGBSTDN_MAJR_CODE_1 not in ('EHS', 'SUS','0000','VIS')
        )
    and SSBSECT.SSBSECT_GMOD_CODE = 'Y'