(SHRLGPA.SHRLGPA_GPA > 3.1750000)

and exists(
        select *

        from SHRTGPA SHRTGPA

        where SHRTGPA.SHRTGPA_PIDM = SPRIDEN.SPRIDEN_PIDM
            and SGBSTDN.SGBSTDN_STYP_CODE not in ('G','T','F','N')
            and SGBSTDN.SGBSTDN_LEVL_CODE not in ('GR')  
    )

and exists(
        select *

        from SFRSTCR SFRSTCR

        where SFRSTCR.SFRSTCR_PIDM = SPRIDEN.SPRIDEN_PIDM
              and SFRSTCR.SFRSTCR_TERM_CODE = STVTERM.STVTERM_CODE
              and SFRSTCR.SFRSTCR_RSTS_CODE in ('RE','RW')
    )