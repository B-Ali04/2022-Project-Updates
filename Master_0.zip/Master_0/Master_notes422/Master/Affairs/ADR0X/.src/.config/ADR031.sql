    SGBSTDN.SGBSTDN_EXP_GRAD_DATE >= to_date(:parm_degree_date_select.STVTERM_START_DATE)
    and SGBSTDN.SGBSTDN_EXP_GRAD_DATE < to_date(:parm_degree_date_select.STVTERM_END_DATE) + 80

    and not exists(
        select *
        from SHRDGMR SHRDGMR
        where SHRDGMR.SHRDGMR_PIDM = SPRIDEN.SPRIDEN_PIDM
        and SHRDGMR.SHRDGMR_LEVL_CODE = SGBSTDN.SGBSTDN_LEVL_CODE
        and SHRDGMR.SHRDGMR_TERM_CODE_COMPLETED > STVTERM.STVTERM_CODE
    )

    and SPRADDR.SPRADDR_ATYP_CODE = :parm_address_type_select.ATYP_CODE