    and SGBSTDN.SGBSTDN_EXP_GRAD_DATE >= to_date(:parm_degree_date_select.STVTERM_START_DATE) 
    and SGBSTDN.SGBSTDN_EXP_GRAD_DATE < to_date(:parm_degree_date_select.STVTERM_END_DATE) + 80

and exists(
       select *
       from SFRSTCR SFRSTCR
       where SFRSTCR.SFRSTCR_PIDM = SPRIDEN.SPRIDEN_PIDM
       and SFRSTCR.SFRSTCR_TERM_CODE = STVTERM.STVTERM_CODE
       and SFRSTCR.SFRSTCR_RSTS_CODE like 'R%')

and SPRADDR.SPRADDR_ATYP_CODE = :parm_address_type_select.ATYP_CODE