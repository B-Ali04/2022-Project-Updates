select  
    GORADID.GORADID_ADDITIONAL_ID SUID,
    rcs.LFMI_NAME Instructor_Name, 
    SSBSECT.SSBSECT_SICAS_CAMP_COURSE_ID || ' - Section: ' || SSBSECT.SSBSECT_SEQ_NUMB || ' - CRN: ' || rcs.CRN Course_Key,
    rcs.TERM_CODE Term_Code, 
    SSBSECT.SSBSECT_ENRL Enrolled_Students, 
    SSBSECT.SSBSECT_SEATS_AVAIL Seats_Available, 
    SSBSECT.SSBSECT_TOT_CREDIT_HRS Course_Credits_Hours

from 
    REL_COURSE_INSTRUCTORS rcs

    join STVTERM STVTERM on STVTERM.STVTERM_CODE = 202150
    
    left outer join SSBSECT SSBSECT on SSBSECT.SSBSECT_CRN = rcs.CRN
    
    left outer join SPRIDEN SPRIDEN on SPRIDEN.SPRIDEN_PIDM = rcs.PIDM and SPRIDEN.SPRIDEN_CHANGE_IND is null and SPRIDEN.SPRIDEN_NTYP_CODE is null
    
    left outer join GORADID GORADID on GORADID.GORADID_PIDM = rcs.PIDM and GORADID.GORADID_ADID_CODE = 'SUID'

where
    rcs.TERM_CODE = STVTERM.STVTERM_CODE

order by
    LFMI_NAME
