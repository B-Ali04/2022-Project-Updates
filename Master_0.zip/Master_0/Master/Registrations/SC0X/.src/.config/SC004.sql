(
        exists(

        select *

        from SFRSTCR r

        where r.SFRSTCR_PIDM = SPRIDEN.SPRIDEN_PIDM
            and r.SFRSTCR_TERM_CODE = STVTERM.STVTERM_CODE
            and r.SFRSTCR_RSTS_CODE like 'R%'
            )
        )

        and SGBSTDN.SGBSTDN_MAJR_CODE_1 in ('SUS')