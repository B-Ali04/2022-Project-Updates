    /*
    This is a thing? I dont remember putting this in?
    */
    and r.PASSED_IND = 0 
    and r.COMPLETE_IND = 0
    and r.GRDE_CODE in ('WF','F')