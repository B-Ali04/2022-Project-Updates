r.term_code != SFRSTCR.SFRSTCR_TERM_CODE
and r.SUBJ_CODE = SSBSECT.SSBSECT_SUBJ_CODE
and r.CRSE_NUMB = SSBSECT.SSBSECT_CRSE_NUMB
and r.GRDE_CODE not in ( 'F', 'I', 'IF', 'IU', 'NR', 'U', 'UAU', 'V', 'W', 'WF')