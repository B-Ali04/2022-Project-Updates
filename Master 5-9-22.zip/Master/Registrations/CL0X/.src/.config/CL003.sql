STVCLAS_CODE in ('FR','SO','JR','SR','S5','AG','BG')
